
document.addEventListener('DOMContentLoaded',function(){
  var t=document.getElementById('navToggle'),links=document.getElementById('navLinks');
  if(t){t.addEventListener('click',function(){links.style.display=links.style.display==='flex'?'none':'flex'});}
  var obs=new IntersectionObserver(function(entries){entries.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in')}});},{threshold:0.12});
  document.querySelectorAll('.fade').forEach(function(el){obs.observe(el);});
  // simple slider for promos/testimonials
  var slides=document.querySelectorAll('.slide'); if(slides.length){var idx=0;slides.forEach((s,i)=>s.style.display=i===0?'block':'none');setInterval(function(){slides[idx].style.display='none';idx=(idx+1)%slides.length;slides[idx].style.display='block';},4500);}
});
